package br.eti.kge.airports;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirportsApplicationTests {

	@Test
	void contextLoads() {
	}

}
